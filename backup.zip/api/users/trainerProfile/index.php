<?php
include("../../../wp-config.php");
$userID = $_GET['userID'];

if ($userID == "") {
    $json = array("success" => 0, "result" => null, "error" => "Todos los campos son obligatorios");
} else {
    $user = get_user_by('ID', $userID);
    if (empty($user)) {
        $json = array("success" => 0, "result" => null, "error" => "Usuario Inválido Invalid");
    } else {
        $phone = get_user_meta($userID , "phone" , true);
        $userImageUrl = get_user_meta($user->ID, "userImageUrl", true);
        $email = $user->data->user_email;
        $first_name = get_user_meta($user->data->ID, "first_name", true);
        $last_name = get_user_meta($user->data->ID, "last_name", true);
        $rating = getUserRating($userID);
        $getMyData = array("userID" => $userID , "firstName" => $first_name, "lastName" => $last_name, "userImageUrl" => $userImageUrl, "phone" => $phone , "emailAddress" => $email , "reviews" => $rating);
        $json = array("success" => 1, "result" => $getMyData, "error" => "No se ha encontrado ningún error");
    }
}
echo json_encode($json);
?>