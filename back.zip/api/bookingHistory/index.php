<?php
include("../../wp-config.php");

date_default_timezone_set("America/Bogota");
$curent = date("Y-m-d H:i:s");
$userID = $_GET['userID'];
$status = $_GET['status'];
$order = $_GET['order'];
$language = $_GET['lang'];

if ($userID == "") {
    $json = array("success" => 0, "result" => array(), "error" => "Todos los campos son obligatorios");
} else {
    $user = get_user_by('ID', $userID);
    if (empty($user)) {
        $json = array("success" => 0, "result" => array(), "error" => "Usuario Inválido");
    } else {

        if($user->roles[0] == "contributor"){
            $getUserDataBooking = $wpdb->get_results("SELECT * FROM `wtw_booking` WHERE `user_id` = $userID AND `status` = $status ORDER BY `booking_date` DESC");
            
        } else {
            $getUserDataBooking = $wpdb->get_results("SELECT * FROM `wtw_booking` WHERE `booking_from` = $userID AND `status` = $status ORDER BY `booking_date` DESC");
          
        }
        if(empty($getUserDataBooking)) {
            $json = array("success" => 0, "result" => array(), "error" => "Datos no encontrados");
        } else {
            $bookingArr = array();
            foreach ($getUserDataBooking as $getUserDataBookingkey => $getUserDataBookingvalue) {
                if($status == 0) {
                    if ($user->roles[0] == "contributor") {
                        $firstNameC = get_user_meta($getUserDataBookingvalue->booking_from, "first_name", true);
                        $lastNameC = get_user_meta($getUserDataBookingvalue->booking_from, "last_name", true);
                        $phone = get_user_meta($getUserDataBookingvalue->booking_from, "phone", true);
                        $userCheck = $getUserDataBookingvalue->booking_from;
                    } else {
                        $firstNameC = get_user_meta($getUserDataBookingvalue->user_id, "first_name", true);
                        $lastNameC = get_user_meta($getUserDataBookingvalue->user_id, "last_name", true);
                        $phone = get_user_meta($getUserDataBookingvalue->user_id, "phone", true);
                        $userCheck = $getUserDataBookingvalue->user_id;
                    }
                    $getCurrentTime = date("Y-m-d");
                    $start = date_create($getUserDataBookingvalue->booking_created);
                    $end = date_create();
                    $diff = date_diff($start, $end);
                   
                    if ($diff->i <= 15 && $diff->h == 0) {
                        $userImageUrl = get_user_meta($getUserDataBookingvalue->ID, "userImageUrl", true);
                        $terMyTerm = get_term($getUserDataBookingvalue->category_id, "category");
                        // echo apply_filters('translate_text', $terMyTerm->name, $lang = $language, $flags = 0);
                        $price = $wpdb->get_results("SELECT * FROM `wtw_usermeta` WHERE `user_id` = $getUserDataBookingvalue->user_id AND `meta_value` = $getUserDataBookingvalue->booking_price");
                        if ($price[0]->meta_key == "single") {
                            $section = 1;
                        } elseif ($price[0]->meta_key == "business") {
                            $section = 2;
                        } else {
                            $section = 3;
                        }
                        $bookingArr[] = array("userID" => (int)$userCheck, "bookingID" => (int)$getUserDataBookingvalue->id, "date" => $getUserDataBookingvalue->booking_date, "category" => apply_filters('translate_text', $terMyTerm->name, $lang = $language, $flags = 0), "categoryID" => (int)$terMyTerm->term_id, "firstName" => $firstNameC, "lastName" => $lastNameC, "bookingStart" => $getUserDataBookingvalue->booking_start, "bookingEnd" => $getUserDataBookingvalue->booking_end, "bookingType" => $section, "phone" => $phone, "userImageUrl" => $userImageUrl, "bookingLatitude" => $getUserDataBookingvalue->booking_latitude, "bookingLongitude" => $getUserDataBookingvalue->booking_longitude, "bookingAddress" => $getUserDataBookingvalue->booking_address);
                    } else {
                        $wpdb->query("UPDATE `wtw_booking` SET `status` = 5, `booking_action_time` = '$curent' WHERE `id` = $getUserDataBookingvalue->id");
                    }
                } else {
                    if ($user->roles[0] == "contributor") {
                        $firstNameC = get_user_meta($getUserDataBookingvalue->booking_from, "first_name", true);
                        $lastNameC = get_user_meta($getUserDataBookingvalue->booking_from, "last_name", true);
                        $phone = get_user_meta($getUserDataBookingvalue->booking_from, "phone", true);
                        $userCheck = $getUserDataBookingvalue->booking_from;
                    } else {
                        $firstNameC = get_user_meta($getUserDataBookingvalue->user_id, "first_name", true);
                        $lastNameC = get_user_meta($getUserDataBookingvalue->user_id, "last_name", true);
                        $phone = get_user_meta($getUserDataBookingvalue->user_id, "phone", true);
                        $userCheck = $getUserDataBookingvalue->user_id;
                    }
                    $userImageUrl = get_user_meta($getUserDataBookingvalue->ID, "userImageUrl", true);
                    $terMyTerm = get_term($getUserDataBookingvalue->category_id, "category");
                    // echo apply_filters('translate_text', $terMyTerm->name, $lang = $language, $flags = 0);
                    $price = $wpdb->get_results("SELECT * FROM `wtw_usermeta` WHERE `user_id` = $getUserDataBookingvalue->user_id AND `meta_value` = $getUserDataBookingvalue->booking_price");
                    if ($price[0]->meta_key == "single") {
                        $section = 1;
                    } elseif ($price[0]->meta_key == "business") {
                        $section = 2;
                    } else {
                        $section = 3;
                    }
                    $bookingArr[] = array("userID" => (int)$userCheck, "bookingID" => (int)$getUserDataBookingvalue->id, "date" => $getUserDataBookingvalue->booking_date, "category" => apply_filters('translate_text', $terMyTerm->name, $lang = $language, $flags = 0), "categoryID" => (int)$terMyTerm->term_id, "firstName" => $firstNameC, "lastName" => $lastNameC, "bookingStart" => $getUserDataBookingvalue->booking_start, "bookingEnd" => $getUserDataBookingvalue->booking_end, "bookingType" => $section, "phone" => $phone, "userImageUrl" => "$userImageUrl", "bookingLatitude" => $getUserDataBookingvalue->booking_latitude, "bookingLongitude" => $getUserDataBookingvalue->booking_longitude, "bookingAddress" => $getUserDataBookingvalue->booking_address , "bookingCreated" => $getUserDataBookingvalue->booking_created , "bookingAccepted" => $getUserDataBookingvalue->booking_action_time);
                }

                
            }

            $bookingArr = str_replace("null", '""', json_encode($bookingArr));
            $json = array("success" => 1, "result" => json_decode($bookingArr), "error" => "No se ha encontrado ningún error");
        }
    }
}
echo json_encode($json);
?>